#include <stdio.h>

int main(){
 int a=5;
 if(a%2==0){
  printf("Even number \n");
 } else {
  printf("Odd number \n");
 }
return 0;
}
