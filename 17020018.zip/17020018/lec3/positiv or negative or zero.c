#include<stdio.h>
int main(){
    int n;
    printf("Input an integer:");
    scanf("%d",&n);
    if(n>0){
        printf("Integer is a positive number.");
    }else if(n<0){
        printf("Integer is a negative number.");
    }else{
        printf("Integer is zero.");
    }
    return 0;
}
