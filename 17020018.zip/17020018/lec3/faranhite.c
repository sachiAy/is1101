#include<stdio.h>
int main(){
    float c = 35;
    float f;
    f = c * 1.8000 + 32.00;
    printf("The faranhite value is: %f\n",f);
    return 0;
}
