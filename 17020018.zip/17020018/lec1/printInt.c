#include <stdio.h>
int main() {

 int testInteger = 5;
//Print Integer here
    printf("%d",testInteger);
 return 0;
}
