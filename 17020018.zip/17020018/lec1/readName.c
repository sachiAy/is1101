#include <stdio.h>
int main() {
 char name[20];

 printf("Enter name: ");
//Read your name and print it
scanf("%c",&name[20]);
printf("%c",name[20]);
 return 0;
}
