#include <stdio.h>

int main(){
 printf("Ayubowan Sachini");
 return 0;
}
