#include <stdio.h>
int main() {
 char ch;

 printf("Enter a character: ");
 scanf("%c",&ch);
 printf("%c",ch);
 //Read and print the character
 return 0;
}
