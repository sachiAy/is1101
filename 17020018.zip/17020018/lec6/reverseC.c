#include <stdio.h>

void reverse(void);

int main(){

 printf("Enter the sentense :");

 reverse();
 printf("\n");
 return 0;
}

void reverse(){
//implement reverse function
    char a;
    scanf("%c",&a);
    if(a!='\n'){
        reverse();
        printf("%c",a);
    }



}
