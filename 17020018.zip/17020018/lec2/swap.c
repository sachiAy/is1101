#include <stdio.h>
int main() {

 double firstNumber, secondNumber, temporaryVariable;
 
 printf("Enter first number: ");
 scanf("%lf", &firstNumber);

 printf("Enter second number: ");
 scanf("%lf",&secondNumber);
 temporaryVariable=firstNumber;
 firstNumber=secondNumber;
 secondNumber=temporaryVariable;
 //Swap two numbers
 
 printf("\nAfter swapping, firstNumber = %.2lf\n", firstNumber);
 printf("After swapping, secondNumber = %.2lf\n", secondNumber);
       
  return 0;
}
