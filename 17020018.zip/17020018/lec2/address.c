#include <stdio.h>

int main(){
 int c=5;

 printf("Address %u \n",&c);
 printf("Value %d \n",c);
  return 0;
}
