#include <stdio.h>
#include <stdlib.h>

int main (int argc,char *argv[]) {

    printf("enter string 1:");
    scanf("%c",&*argv[1]);
     printf("enter string 2:");
    scanf("%c",&*argv[2]);

  printf ("The value entered is %s and %s.\n",argv[1],argv[2]);
  if(argc<3) return 1;
  int sum=atoi(*argv[1])+atoi(*argv[2]);


  return 0;
}
