#include <stdio.h>
int main(){
    long a,n;
    int x=0;
    printf("Enter a number:");
    scanf("%ld",&a);

        while(a>0){
            n=a%10;
            x=x*10+n;
            a=a/10;
        }
        printf("reverce:%ld",x);

    return 0;
}

