#include <stdio.h>

int main(){
int n;
int sum=0;
//Write a for loop to add numbers
    printf("Enter a numer:");
    scanf("%d",&n);
for(int i=0;i<=n;i++){
    sum=sum+i;
}


printf("Sum %d \n",sum);
}
