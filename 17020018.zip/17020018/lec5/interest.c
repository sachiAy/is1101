#include <stdio.h>
double rate(double);
double interest(double);


double rate(double amount){
//Implement this function
    if(amount<=10000){
        return .04;
    }else if(amount<=100000){
            return .05;
    }else if(amount<=1000000){
        return .1;
    }else{
        return .15;
    }

}

double interest(double amount){
      return amount*rate(amount);
}
int main(){
    double a;
    printf("Enter amount:");
    scanf("%lf",&a);

    printf("Interest is:%lf",interest(a));
    return 0;
}

