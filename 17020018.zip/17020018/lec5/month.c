#include<stdio.h>
int leap(int year);
int daysInMonth(int year,int n);
int main(){
    int n,year;
    printf("Enter the number of month:");
    scanf("%d",&n);
    leap(year);
    daysInMonth(year,n);
    printf("Days in month %d:%d\n ",n,daysInMonth(year,n));
int daysInMonth(int year,int n){
 int days=0;

 switch(n){
   case 1:
       days=31;
       break;
   case 3:
       days=31;
       break;
   case 5:
       days=31;
       break;
   case 7:
       days=31;
       break;
   case 9:
       days=30;
       break;
   case 11:
       days=30;
       break;
   case 2:
       if(leap(year))
            days=29;
        else
            days=28;
       break;
   case 4:
       days=30;
       break;
   case 6:
       days=30;
       break;
   case 8:
       days=31;
       break;
   case 10:
       days=31;
       break;
   case 12:
       days=31;
       break;
 }
 return days;
}
}
int leap(int year) {
  int true=1;

  if (year%4!=0){
        true=0;
        printf("Not a leap year.");
  }else if (year%100==0 && year%400!=0){
      true=0;
       printf("Not a leap year.");
  }else {
      true=1;
       printf("a leap year.");
  }return true;
}

