#include <stdio.h>

int prime(int n);

int main(){
 int n=0;
 int count=0;
 printf("Enter a Number :");
 scanf("%d",&n);
prime(n);

 return 0;
}

int prime(int n){
//Implement it
int count=0;
for(int i=1;i<=n;i++){

    if(n%i==0)
        count++;
            if(count==2){
                printf("%d is a prime number",n);
                break;
            }else{

        }

    }printf("%d is not a prime number",n);

    return 0;
}


