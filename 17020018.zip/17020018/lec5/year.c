#include<stdio.h>
int leap(int);
int daysInMonth(int year,int month);

int main(){
int year=0,month=0;
  //Need to continue it till someone enter negative value
  // for year or month
{
  printf("Enter Year and Month:");
  scanf("%d %d",&year,&month);
  if(leap(year)) printf("%d is leap year.\n",year);
  else printf("%d is not leap year. \n",year);

  printf("%d days in the year %d.\n",daysInMonth(year,month),year);
 }
return 0;
}
int leap(int year) {
  int true=1;

  if (year%4!=0){
        true=0;

  }else if (year%100==0 && year%400!=0){
      true=0;

  }else {
      true=1;

  }return true;
}
int daysInMonth(int year,int month){
    int days;
    if(leap(year)){
       return days=366;
    }else{
        return days=365;
    }
    return 0;
}
