#include<stdio.h>
int leap(int year) {
  int true=1;

  if (year%4!=0){
        true=0;
        printf("Not a leap year.");
  }else if (year%100==0 && year%400!=0){
      true=0;
       printf("Not a leap year.");
  }else {
      true=1;
       printf("a leap year.");
  }return true;
}
int main(){
    int year;
    printf("Enter a year:");
    scanf("%d",&year);
    leap(year);
    return 0;
}
