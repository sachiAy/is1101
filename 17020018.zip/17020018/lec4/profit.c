#include <stdio.h>

#define profit(revenue,cost)

#define revenue(price,n)

#define cost(n)

#define attendees(price)

int main(){
 int price=15;
 int n=(15-price)/5*20+120;
 int cost=500+n*3;
 float revenue=price*n;
 float profit=(revenue-cost);
    printf("Ticket Price = %d => profit = %.2f\n",price,profit);
 return 0;
}
