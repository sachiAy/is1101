#include <stdio.h>

int main(){
    int wage = 150*40;
    int ot = 75*20;
    int total = wage + ot;
    int tax = total *10 / 100;
    int takehome = total - tax ;

    printf("Take home salary is %d ",takehome);

return 0;
}

