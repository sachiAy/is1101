#include <stdio.h>

int main(){
 printf("Date %s \n", __DATE__);
 printf("Time %s \n",__TIME__);
}
