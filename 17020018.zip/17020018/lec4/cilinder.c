#include <stdio.h>

#define PI 3.14
#define circleArea(r) (PI*r*r)
#define r 1.9

int main(){
 printf("Area of the Circle = %.2f \n",circleArea(r));
 return 0;
}
