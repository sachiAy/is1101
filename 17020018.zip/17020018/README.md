# IS1101 
<h2>Programming and Problem Solving</h2>
In this course, student will learn an overview and history of programming
languages and different features of programing languages. Program design
techniques and programming also discuss in this course module. This course
will be introduced to programme design and development approaches
including database accessing and file handling approaches. problem solving
application will be discussed throughout the course
<br>
<h2>Upon completion of this course, students will be able to do the
following:</h2>
<br>LO1. Understand the overview and history of programming languages
<br>LO2. Understand different programme design and development
approaches
<br>LO3. Understand and apply techniques for modelling programme
structures, algorithms, flow charts, pseudo codes and hand traces
<br>LO4. Understand how to use constants, variables, literals, primitive data
types, and expressions.
<br>LO5. Learn how to use procedures, functions, parameters and passing parameters
<br>LO6. Learn how to write codes when solving simple problems,
<br>LO7. Understand and apply control structures, sequential conditional and recursion
<br>LO8. Understand and apply file handling and problem solving application

<h3>Assignments: 40%</h3>
<h3>Examination: 60%</h3>
